<?php
$pageTitle = 'Browse Packages';
require_once __DIR__ . '/../includes/header.php';
requireRole(['customer']);
requireApproved();

// Ensure generated images are saved in assets/images/
@include_once __DIR__ . '/../copy_images.php';

$db = getDB();
$userId = $_SESSION['user_id'] ?? 0;

// Auto-sync past bookings to free up slots in real-time
syncPastBookingsAndSlots($db);

$ongoingBookings = getCustomerOngoingBookings($userId);
$hasOngoingPayment = !empty($ongoingBookings);
$totalOngoingBalance = array_sum(array_column($ongoingBookings, 'calculated_balance'));

// Ensure discount columns exist
ensureDiscountColumns($db);

// Fetch active packages with live available slot counts (only future bookings occupy slots)
$packages = $db->query("
    SELECT p.*, p.package_id AS id, p.package_name AS name,
           p.base_price AS price,
           COALESCE(p.full_payment_discount_percent, 10.00) AS full_payment_discount_percent,
           COALESCE(p.downpayment_discount_percent, 5.00) AS downpayment_discount_percent,
           COALESCE(p.downpayment_percent, 50.00) AS downpayment_percent,
           COALESCE(p.max_slots, 5) AS max_slots,
           (SELECT COUNT(*) FROM bookings b
            WHERE b.package_id = p.package_id
            AND b.status IN ('Pending','Confirmed','Paid')
            AND b.event_date >= CURDATE()) AS active_bookings,
           GREATEST(0, COALESCE(p.max_slots, 5) - (SELECT COUNT(*) FROM bookings b
            WHERE b.package_id = p.package_id
            AND b.status IN ('Pending','Confirmed','Paid')
            AND b.event_date >= CURDATE())) AS available_slots
    FROM packages p
    WHERE p.status = 'active'
    ORDER BY p.base_price ASC
")->fetchAll();

// Fallback images map by event_type
$defaultImages = [
    'Wedding'    => 'assets/images/packages/wedding.png',
    'Birthday'   => 'assets/images/packages/birthday.png',
    'Debut'      => 'assets/images/packages/debut.png',
    'Christening'=> 'assets/images/packages/christening.png',
];

// Attach components for each package
foreach ($packages as &$pkg) {
    $compStmt = $db->prepare("
        SELECT category, name, description FROM package_components
        WHERE package_id = ? ORDER BY category, name
    ");
    $compStmt->execute([$pkg['package_id'] ?? $pkg['id']]);
    $pkg['components'] = $compStmt->fetchAll();
}
unset($pkg);

$catIcons = [
    'venue'       => 'fa-building',
    'food'        => 'fa-utensils',
    'photography' => 'fa-camera',
    'decoration'  => 'fa-palette'
];
?>

<?php require_once __DIR__ . '/../includes/navbar.php'; ?>

<div class="page-header" style="background: linear-gradient(135deg, rgba(78,205,196,0.1), rgba(233,69,96,0.07)); border: 1px solid rgba(78,205,196,0.2); border-radius: 20px; padding: 28px 32px; margin-bottom: 28px; position: relative; overflow: hidden;">
    <div style="position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #e94560, #f5a623, #4ecdc4, #9b59b6);"></div>
    <div>
        <div style="display:inline-flex; align-items:center; gap:8px; background:rgba(78,205,196,0.12); border:1px solid rgba(78,205,196,0.3); color:#4ecdc4; padding:5px 14px; border-radius:20px; font-size:0.78rem; font-weight:700; text-transform:uppercase; letter-spacing:0.06em; margin-bottom:12px;">
            <i class="fa-solid fa-box-open"></i> Package Catalog
        </div>
        <h1 style="font-family:'Outfit',sans-serif; font-size:1.9rem; font-weight:800; margin-bottom:6px;">Browse Packages</h1>
        <p style="color: var(--text-secondary); font-size:0.92rem;">Choose from our curated craft event packages — each with complete inclusions &amp; visual previews</p>
    </div>
    <div style="display:flex; gap:24px; flex-shrink:0;">
        <div style="text-align:center;">
            <div style="font-family:'Outfit',sans-serif; font-size:1.6rem; font-weight:800; color:#4ecdc4;"><?= count($packages) ?></div>
            <div style="font-size:0.75rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.05em;">Packages</div>
        </div>
    </div>
</div>

<?php displayFlash(); ?>

<?php if ($hasOngoingPayment): ?>
<!-- Ongoing Payment Restriction Banner -->
<div class="card" style="margin-bottom:24px;background:linear-gradient(135deg,rgba(233,69,96,0.12),rgba(245,166,35,0.08));border:1.5px solid rgba(233,69,96,0.5);border-radius:18px;padding:22px 26px;position:relative;overflow:hidden;">
    <div style="position:absolute;top:0;left:0;bottom:0;width:5px;background:linear-gradient(180deg,#e94560,#f5a623);"></div>
    <div style="display:flex;align-items:flex-start;gap:18px;">
        <div style="width:48px;height:48px;border-radius:14px;background:rgba(233,69,96,0.22);border:1px solid rgba(233,69,96,0.4);display:flex;align-items:center;justify-content:center;color:#e94560;font-size:1.35rem;flex-shrink:0;">
            <i class="fa-solid fa-lock"></i>
        </div>
        <div style="flex:1;">
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                <h3 style="margin:0;font-size:1.2rem;font-weight:800;color:#fff;font-family:'Outfit',sans-serif;">Package Booking Temporarily Locked</h3>
                <span style="background:rgba(233,69,96,0.2);color:#e94560;border:1px solid rgba(233,69,96,0.4);padding:3px 10px;border-radius:20px;font-size:0.75rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;">Full Payment Required</span>
            </div>
            <p style="color:var(--text-secondary);font-size:0.92rem;margin:8px 0 14px 0;line-height:1.5;">
                You currently have an ongoing payment / unpaid balance of <strong style="color:#e94560;font-size:1.05rem;"><?= formatCurrency($totalOngoingBalance) ?></strong> across your existing booking(s).
                CraftHub policy requires all ongoing bookings to be <strong>fully paid</strong> before you can purchase or book another package.
            </p>
            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
                <a href="<?= APP_URL ?>/customer/bookings.php" class="btn btn-primary btn-sm">
                    <i class="fa-solid fa-file-invoice-dollar"></i> View My Bookings &amp; Balances
                </a>
                <a href="<?= APP_URL ?>/customer/payment_history.php" class="btn btn-secondary btn-sm">
                    <i class="fa-solid fa-receipt"></i> Payment History
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Event Type Category Filter Tabs -->
<div style="display:flex;gap:10px;margin-bottom:24px;flex-wrap:wrap;align-items:center;">
    <span style="font-size:0.85rem;color:var(--text-muted);font-weight:700;margin-right:4px;">
        <i class="fa-solid fa-filter"></i> Filter by Event:
    </span>
    <button class="event-filter-tab active" data-type="all" onclick="filterPackages('all')">
        <i class="fa-solid fa-border-all"></i> All Packages
    </button>
    <button class="event-filter-tab" data-type="Wedding" onclick="filterPackages('Wedding')">
        💍 Wedding
    </button>
    <button class="event-filter-tab" data-type="Birthday" onclick="filterPackages('Birthday')">
        🎂 Birthday
    </button>
    <button class="event-filter-tab" data-type="Debut" onclick="filterPackages('Debut')">
        💃 Debut
    </button>
    <button class="event-filter-tab" data-type="Christening" onclick="filterPackages('Christening')">
        🕊️ Christening
    </button>
</div>

<style>
.event-filter-tab {
    padding: 8px 18px;
    border-radius: 30px;
    font-family: 'Outfit', sans-serif;
    font-size: 0.85rem;
    font-weight: 700;
    color: var(--text-secondary);
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    cursor: pointer;
    transition: all 0.25s ease;
}
.event-filter-tab:hover {
    color: #fff;
    background: rgba(255,255,255,0.1);
    border-color: rgba(255,255,255,0.2);
    transform: translateY(-1px);
}
.event-filter-tab.active {
    background: linear-gradient(135deg, #e94560, #c0392b);
    color: #fff;
    border-color: rgba(233,69,96,0.4);
    box-shadow: 0 4px 14px rgba(233,69,96,0.4);
}
.comp-cat-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 0.7rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    padding: 2px 8px;
    border-radius: 6px;
    margin-bottom: 4px;
}
.cat-venue       { background: rgba(39,174,96,0.15); color: #27ae60; border: 1px solid rgba(39,174,96,0.3); }
.cat-food        { background: rgba(245,166,35,0.15); color: #f5a623; border: 1px solid rgba(245,166,35,0.3); }
.cat-photography { background: rgba(78,205,196,0.15); color: #4ecdc4; border: 1px solid rgba(78,205,196,0.3); }
.cat-decoration  { background: rgba(168,85,247,0.15); color: #a855f7; border: 1px solid rgba(168,85,247,0.3); }
</style>

<?php if (empty($packages)): ?>
    <div class="empty-state">
        <i class="fa-solid fa-box-open"></i>
        <h3>No Packages Available</h3>
        <p>Check back soon for exciting craft packages!</p>
    </div>
<?php else: ?>
    <div class="packages-page grid-auto" style="padding-bottom: 40px;">
        <?php foreach ($packages as $pkg):
            $maxSlots    = (int)($pkg['max_slots'] ?? 5);
            $available   = (int)($pkg['available_slots'] ?? 0);  // from DB: slots minus active bookings
            $activeBooks = (int)($pkg['active_bookings'] ?? 0);
            $bookedCount = $activeBooks; // used for the progress bar
            $isFull      = $available <= 0;
            $pctBooked   = $maxSlots > 0 ? min(100, round($activeBooks / $maxSlots * 100)) : 100;
            $slotColor   = $available <= 1 ? '#e94560' : ($available <= 3 ? '#f5a623' : '#27ae60');
            $components  = $pkg['components'] ?? [];
            
            // Image fallback logic
            $imgPath     = !empty($pkg['image_url']) ? $pkg['image_url'] : ($defaultImages[$pkg['event_type']] ?? 'assets/images/packages/wedding.png');
        ?>
        <div class="package-card pkg-item-card" data-event-type="<?= htmlspecialchars($pkg['event_type']) ?>" data-package-id="<?= (int)$pkg['id'] ?>" style="overflow:hidden;<?= $isFull ? 'opacity:0.75;' : '' ?>">

            <!-- Package Preview Image -->
            <div style="position:relative;height:180px;overflow:hidden;background:#1a1a2e;">
                <img src="<?= APP_URL ?>/<?= htmlspecialchars($imgPath) ?>"
                     alt="<?= htmlspecialchars($pkg['name'] ?? $pkg['package_name']) ?>"
                     style="width:100%;height:100%;object-fit:cover;display:block;transition:transform 0.4s ease;"
                     onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
                
                <!-- Fallback icon container if image fails -->
                <div style="display:none;width:100%;height:100%;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--accent-teal),var(--accent-purple));color:#fff;font-size:3rem;">
                    <i class="fa-solid fa-palette"></i>
                </div>

                <div style="position:absolute;top:12px;left:12px;background:rgba(15,15,26,0.75);backdrop-filter:blur(6px);color:var(--accent-teal);border:1px solid rgba(78,205,196,0.3);padding:4px 12px;border-radius:20px;font-size:0.78rem;font-weight:600;display:flex;align-items:center;gap:6px;">
                    <i class="fa-solid fa-gift"></i> <?= htmlspecialchars($pkg['event_type']) ?>
                </div>

                <?php if ($isFull): ?>
                    <div style="position:absolute;top:12px;right:12px;background:rgba(233,69,96,0.9);color:#fff;padding:4px 10px;border-radius:20px;font-size:0.75rem;font-weight:700;">
                        <i class="fa-solid fa-ban"></i> FULL
                    </div>
                <?php endif; ?>
            </div>

            <div class="package-card-header" style="padding-top:14px;">
                <div class="package-card-title"><?= htmlspecialchars($pkg['name'] ?? $pkg['package_name']) ?></div>
                <div class="package-price" style="display:flex;flex-direction:column;align-items:flex-start;gap:2px;">
                    <?php
                    $basePrice = (float)($pkg['price'] ?? $pkg['base_price']);
                    $fullDiscPct = (float)($pkg['full_payment_discount_percent'] ?? 10);
                    $dpDiscPct = (float)($pkg['downpayment_discount_percent'] ?? 5);
                    $discountedFullPrice = $basePrice * (1 - ($fullDiscPct / 100));
                    ?>
                    <?php if ($fullDiscPct > 0 || $dpDiscPct > 0): ?>
                        <div style="font-size:0.85rem;text-decoration:line-through;color:var(--text-muted);font-weight:400;">
                            <?= formatCurrency($basePrice) ?>
                        </div>
                        <div style="display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;">
                            <span style="font-size:1.35rem;font-weight:700;color:var(--accent-teal);line-height:1.2;">
                                <?= formatCurrency($discountedFullPrice) ?>
                            </span>
                            <span class="badge" style="background:rgba(46,204,113,0.15);color:#2ecc71;border:1px solid rgba(46,204,113,0.35);font-size:0.75rem;padding:2px 8px;border-radius:12px;font-weight:600;">
                                <i class="fa-solid fa-tag"></i> Up to <?= rtrim(rtrim(number_format($fullDiscPct, 2), '0'), '.') ?>% OFF
                            </span>
                        </div>
                        <div style="font-size:0.75rem;color:var(--text-secondary);margin-top:2px;">
                            Full: <?= rtrim(rtrim(number_format($fullDiscPct, 2), '0'), '.') ?>% off &bull; DP: <?= rtrim(rtrim(number_format($dpDiscPct, 2), '0'), '.') ?>% off
                        </div>
                    <?php else: ?>
                        <div style="font-size:1.35rem;font-weight:700;color:var(--accent-teal);">
                            <?= formatCurrency($basePrice) ?>
                            <span style="font-size:0.85rem;font-weight:normal;color:var(--text-muted);">/ booking</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="package-card-body">
                <p class="package-description">
                    <?= htmlspecialchars($pkg['description'] ?: 'A wonderful craft experience awaits you!') ?>
                </p>

                <!-- Included Details Section for Customer -->
                <div style="margin-top:14px;padding:12px;background:rgba(78,205,196,0.06);border:1px solid rgba(78,205,196,0.2);border-radius:var(--radius-sm);">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
                        <span style="color:var(--accent-teal);font-weight:700;font-size:0.82rem;text-transform:uppercase;letter-spacing:0.04em;">
                            <i class="fa-solid fa-list-check" style="margin-right:4px;"></i> Included Details:
                        </span>
                        <span class="badge badge-info" style="font-size:0.72rem;padding:2px 7px;">
                            <?= count($components) ?> Item<?= count($components) !== 1 ? 's' : '' ?>
                        </span>
                    </div>

                    <?php if (!empty($components)):
                        // Group components by category for organized display
                        $groupedComps = [];
                        foreach ($components as $c) {
                            $groupedComps[$c['category']][] = $c;
                        }
                        $catLabels = [
                            'venue'       => ['label' => 'Venue & Facilities', 'icon' => 'fa-building', 'class' => 'cat-venue'],
                            'food'        => ['label' => 'Food & Catering',     'icon' => 'fa-utensils', 'class' => 'cat-food'],
                            'photography' => ['label' => 'Photo & Video',       'icon' => 'fa-camera',   'class' => 'cat-photography'],
                            'decoration'  => ['label' => 'Decor & Styling',     'icon' => 'fa-palette',  'class' => 'cat-decoration']
                        ];
                    ?>
                        <div style="display:flex;flex-direction:column;gap:10px;">
                            <?php foreach ($catLabels as $catKey => $catMeta): ?>
                                <?php if (!empty($groupedComps[$catKey])): ?>
                                    <div>
                                        <span class="comp-cat-badge <?= $catMeta['class'] ?>">
                                            <i class="fa-solid <?= $catMeta['icon'] ?>"></i> <?= $catMeta['label'] ?>
                                        </span>
                                        <ul style="list-style:none;padding:0;margin:4px 0 0 0;display:grid;gap:4px;">
                                            <?php foreach ($groupedComps[$catKey] as $c): ?>
                                                <li style="font-size:0.82rem;color:var(--text-primary);padding-left:6px;border-left:2px solid rgba(255,255,255,0.1);">
                                                    <strong><?= htmlspecialchars($c['name']) ?></strong>
                                                    <?php if (!empty($c['description'])): ?>
                                                        <span style="font-size:0.75rem;color:var(--text-secondary);display:block;"><?= htmlspecialchars($c['description']) ?></span>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div style="font-size:0.8rem;color:var(--text-muted);font-style:italic;">
                            Standard craft package setup and coordination included.
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Slot Availability -->
                <div class="slot-availability-section" data-slot-pkg="<?= (int)$pkg['id'] ?>" style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border-color);">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                        <span style="font-size:0.8rem;font-weight:600;color:var(--text-secondary);">
                            <i class="fa-solid fa-calendar-days"></i> Slot Availability
                        </span>
                        <span class="slot-status-text" style="font-size:0.8rem;font-weight:700;color:<?= $isFull ? '#e94560' : $slotColor ?>;">
                            <?php if ($isFull): ?>
                                <i class="fa-solid fa-circle-xmark"></i> Fully Booked
                            <?php else: ?>
                                <?= $available ?> of <?= $maxSlots ?> slot<?= $maxSlots > 1 ? 's' : '' ?> left
                            <?php endif; ?>
                        </span>
                    </div>
                    <!-- Progress Bar -->
                    <div style="background:var(--bg-card);border:1px solid var(--border-color);border-radius:20px;height:8px;overflow:hidden;">
                        <div class="slot-progress-bar" style="height:100%;width:<?= $pctBooked ?>%;background:<?= $slotColor ?>;border-radius:20px;transition:width 0.6s ease;"></div>
                    </div>
                    <p class="slot-warning-text" style="font-size:0.78rem;margin-top:6px;<?php if ($isFull): ?>color:var(--text-muted);text-align:center;<?php elseif ($available <= 2): ?>color:#f5a623;font-weight:600;<?php else: ?>display:none;<?php endif; ?>">
                        <?php if ($isFull): ?>
                            This package is currently fully booked. Please check back later.
                        <?php elseif ($available <= 2): ?>
                            <i class="fa-solid fa-triangle-exclamation"></i> Only <?= $available ?> slot<?= $available > 1 ? 's' : '' ?> remaining — book now!
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            <div class="package-card-footer">
                <div class="slot-book-action" data-book-pkg="<?= (int)$pkg['id'] ?>">
                <?php if ($isFull): ?>
                    <button class="btn btn-secondary btn-block btn-fully-booked" disabled style="cursor:not-allowed;opacity:0.6;">
                        <i class="fa-solid fa-ban"></i> Fully Booked
                    </button>
                <?php elseif ($hasOngoingPayment): ?>
                    <button class="btn btn-secondary btn-block btn-payment-lock" disabled style="cursor:not-allowed;opacity:0.85;background:rgba(233,69,96,0.15);border:1px solid rgba(233,69,96,0.35);color:#e94560;font-weight:700;" title="You must settle all ongoing payments before booking a new package.">
                        <i class="fa-solid fa-lock"></i> Full Payment Required
                    </button>
                <?php else: ?>
                    <a href="<?= APP_URL ?>/customer/booking.php?package_id=<?= $pkg['id'] ?>" class="btn btn-primary btn-block btn-book-now">
                        <i class="fa-solid fa-calendar-plus"></i> Book This Package
                    </a>
                <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
function filterPackages(eventType) {
    document.querySelectorAll('.event-filter-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.type === eventType);
    });

    document.querySelectorAll('.pkg-item-card').forEach(card => {
        const cardType = card.dataset.eventType;
        if (eventType === 'all' || cardType === eventType) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
}

// ── Real-Time Slot Availability Polling ──────────────────────
(function() {
    const BASE = '<?= APP_URL ?>';
    const HAS_ONGOING = <?= $hasOngoingPayment ? 'true' : 'false' ?>;
    const POLL_INTERVAL = 30000; // 30 seconds

    function getSlotColor(available) {
        if (available <= 1) return '#e94560';
        if (available <= 3) return '#f5a623';
        return '#27ae60';
    }

    function refreshSlots() {
        fetch(BASE + '/customer/api_slots.php', { credentials: 'same-origin' })
            .then(r => r.json())
            .then(data => {
                if (!data.packages) return;

                data.packages.forEach(pkg => {
                    const card = document.querySelector(`.pkg-item-card[data-package-id="${pkg.id}"]`);
                    if (!card) return;

                    const slotSection = card.querySelector('.slot-availability-section');
                    const statusText  = card.querySelector('.slot-status-text');
                    const progressBar = card.querySelector('.slot-progress-bar');
                    const warningText = card.querySelector('.slot-warning-text');
                    const bookAction  = card.querySelector('.slot-book-action');
                    if (!slotSection || !statusText || !progressBar) return;

                    const color = getSlotColor(pkg.available_slots);
                    const isFull = pkg.is_full;

                    // Update card opacity
                    card.style.opacity = isFull ? '0.75' : '1';

                    // Update status text
                    if (isFull) {
                        statusText.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> Fully Booked';
                        statusText.style.color = '#e94560';
                    } else {
                        const slotWord = pkg.max_slots > 1 ? 'slots' : 'slot';
                        statusText.textContent = `${pkg.available_slots} of ${pkg.max_slots} ${slotWord} left`;
                        statusText.style.color = color;
                    }

                    // Update progress bar
                    progressBar.style.width = pkg.pct_booked + '%';
                    progressBar.style.background = color;

                    // Update warning text
                    if (warningText) {
                        if (isFull) {
                            warningText.style.display = '';
                            warningText.style.color = 'var(--text-muted)';
                            warningText.style.textAlign = 'center';
                            warningText.style.fontWeight = 'normal';
                            warningText.textContent = 'This package is currently fully booked. Please check back later.';
                        } else if (pkg.available_slots <= 2) {
                            warningText.style.display = '';
                            warningText.style.color = '#f5a623';
                            warningText.style.textAlign = '';
                            warningText.style.fontWeight = '600';
                            const slotWord = pkg.available_slots > 1 ? 'slots' : 'slot';
                            warningText.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> Only ${pkg.available_slots} ${slotWord} remaining — book now!`;
                        } else {
                            warningText.style.display = 'none';
                        }
                    }

                    // Update book button
                    if (bookAction) {
                        if (isFull) {
                            bookAction.innerHTML = `<button class="btn btn-secondary btn-block btn-fully-booked" disabled style="cursor:not-allowed;opacity:0.6;">
                                <i class="fa-solid fa-ban"></i> Fully Booked
                            </button>`;
                        } else if (HAS_ONGOING) {
                            bookAction.innerHTML = `<button class="btn btn-secondary btn-block btn-payment-lock" disabled style="cursor:not-allowed;opacity:0.85;background:rgba(233,69,96,0.15);border:1px solid rgba(233,69,96,0.35);color:#e94560;font-weight:700;" title="You must settle all ongoing payments before booking a new package.">
                                <i class="fa-solid fa-lock"></i> Full Payment Required
                            </button>`;
                        } else {
                            bookAction.innerHTML = `<a href="${BASE}/customer/booking.php?package_id=${pkg.id}" class="btn btn-primary btn-block btn-book-now">
                                <i class="fa-solid fa-calendar-plus"></i> Book This Package
                            </a>`;
                        }
                    }
                });
            })
            .catch(() => {}); // Silent fail - will retry next interval
    }

    // Poll every 30 seconds
    setInterval(refreshSlots, POLL_INTERVAL);
})();
</script>

